/* 
 * File:   FT800_main.c
 * Author: sabri dageri
 *www.ozdisan.com
 * hardware 	OZD-EVA-FT800-PIC-V1.1 demo board
 * https://www.ozdisan.com/tools-supplies-assistant-equipments/evaluation-and-demo-boards-kits/evaluation-boards/OZD-EVA-FT800-PIC-V1-1
 * software OZD-PIC18F46K20-FT800_basics_V1
 * Created on 27 jan 2017
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include "FT800.h"

#define Led_1 PORTBbits.RB3
#define Led_2 PORTBbits.RB4
#define CS_Pin PORTEbits.RE0
#define PD_Pin PORTEbits.RE1
#define SPI_MOSI PORTCbits.RC5
#define SPI_MISO PORTCbits.RC4
#define SPI_SCK PORTCbits.RC3


// FT800 Chip Commands - use with cmdWrite
#define FT800_ACTIVE        0x00                        // Initializes FT800
#define FT800_STANDBY       0x41                        // Place FT800 in Standby (clk running)
#define FT800_SLEEP         0x42                        // Place FT800 in Sleep (clk off)
#define FT800_PWRDOWN       0x50                        // Place FT800 in Power Down (core off)
#define FT800_CLKEXT        0x44                        // Select external clock source
#define FT800_CLK48M        0x62                        // Select 48MHz PLL
#define FT800_CLK36M        0x61                        // Select 36MHz PLL
#define FT800_CORERST       0x68                        // Reset core - all registers default
#define FT800_GPUACTIVE     0x40
// FT800 Memory Commands - use with ft800memWritexx and ft800memReadxx
#define MEM_WRITE        0x80                        // FT800 Host Memory Write
#define MEM_READ         0x00                        // FT800 Host Memory Read

// Colors - fully saturated colors defined here
#define RED                  0xFF0000                // Red
#define GREEN                0x00FF00                // Green
#define BLUE                 0x0000FF                // Blue
#define WHITE                0xFFFFFF                // White
#define BLACK                0x000000                // Black

#define _XTAL_FREQ 8000000      // Required for _delay() function, internal OSC Max

// LCD display parameters
unsigned int lcdWidth;                                // Active width of LCD display
unsigned int lcdHeight;                                // Active height of LCD display
unsigned int lcdHcycle;                                // Total number of clocks per line
unsigned int lcdHoffset;                        // Start of active line
unsigned int lcdHsync0;                                // Start of horizontal sync pulse
unsigned int lcdHsync1;                                // End of horizontal sync pulse
unsigned int lcdVcycle;                                // Total number of lines per screen
unsigned int lcdVoffset;                        // Start of active screen
unsigned int lcdVsync0;                                // Start of vertical sync pulse
unsigned int lcdVsync1;                                // End of vertical sync pulse
unsigned char lcdPclk;                                // Pixel Clock
unsigned char lcdSwizzle;                        // Define RGB output pins
unsigned char lcdPclkpol;                        // Define active edge of PCLK

unsigned long ramDisplayList = RAM_DL;                // Set beginning of display list memory
unsigned long ramCommandBuffer = RAM_CMD;        // Set beginning of graphics command memory

unsigned int cmdBufferRd;                // Used to navigate command ring buffer
unsigned int cmdBufferWr = 0x0000;                // Used to navigate command ring buffer
unsigned int cmdOffset = 0x0000;                // Used to navigate command rung buffer
unsigned int point_size = 0x0100;                // Define a default dot size
unsigned long point_x = (96 * 16);                // Define a default point x-location (1/16 anti-aliased)
unsigned long point_x2 = (100 * 16);
unsigned long point_y = (136 * 16);                // Define a default point y-location (1/16 anti-aliased)
unsigned long color;                                // Variable for chanign colors
unsigned char ft800Gpio;                        // Used for FT800 GPIO register
unsigned char page_update;
unsigned char page_number;
unsigned long slider_value;
unsigned long toggle_state;
unsigned char update_toggle=0;


// CONFIG1H
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit (Oscillator Switchover mode disabled)

// CONFIG2L
#pragma config PWRT = OFF       // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = SBORDIS  // Brown-out Reset Enable bits (Brown-out Reset enabled in hardware only (SBOREN is disabled))
#pragma config BORV = 18        // Brown Out Reset Voltage bits (VBOR set to 1.8 V nominal)

// CONFIG2H
#pragma config WDTEN = OFF      // Watchdog Timer Enable bit (WDT is controlled by SWDTEN bit of the WDTCON register)
#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)

// CONFIG3H
#pragma config CCP2MX = PORTC   // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
#pragma config PBADEN = ON      // PORTB A/D Enable bit (PORTB<4:0> pins are configured as analog input channels on Reset)
#pragma config LPT1OSC = OFF    // Low-Power Timer1 Oscillator Enable bit (Timer1 configured for higher power operation)
#pragma config HFOFST = ON      // HFINTOSC Fast Start-up (HFINTOSC starts clocking the CPU without waiting for the oscillator to stablize.)
#pragma config MCLRE = ON      // MCLR Pin Enable bit (MCLR pin enabled; RE3 input pin disabled)

// CONFIG4L
#pragma config STVREN = ON      // Stack Full/Underflow Reset Enable bit (Stack full/underflow will cause Reset)
#pragma config LVP = OFF        // Single-Supply ICSP Enable bit (Single-Supply ICSP enabled)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection Block 0 (Block 0 (000800-001FFFh) not code-protected)
#pragma config CP1 = OFF        // Code Protection Block 1 (Block 1 (002000-003FFFh) not code-protected)
#pragma config CP2 = OFF        // Code Protection Block 2 (Block 2 (004000-005FFFh) not code-protected)
#pragma config CP3 = OFF        // Code Protection Block 3 (Block 3 (006000-007FFFh) not code-protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) not code-protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM not code-protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection Block 0 (Block 0 (000800-001FFFh) not write-protected)
#pragma config WRT1 = OFF       // Write Protection Block 1 (Block 1 (002000-003FFFh) not write-protected)
#pragma config WRT2 = OFF       // Write Protection Block 2 (Block 2 (004000-005FFFh) not write-protected)
#pragma config WRT3 = OFF       // Write Protection Block 3 (Block 3 (006000-007FFFh) not write-protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot Block (000000-0007FFh) not write-protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM not write-protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection Block 0 (Block 0 (000800-001FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection Block 1 (Block 1 (002000-003FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection Block 2 (Block 2 (004000-005FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR3 = OFF      // Table Read Protection Block 3 (Block 3 (006000-007FFFh) not protected from table reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF      // Boot Block Table Read Protection bit (Boot Block (000000-0007FFh) not protected from table reads executed in other blocks)


 
void write_soft_SPI(unsigned char value)
{
    unsigned char i;
    SPI_SCK=0; 
    __delay_us(1);
    for(i=0;i<8;i++)
    {
      if(value&(0x80>>i))
      {
         SPI_MOSI=1; 
      }
      else
      {
         SPI_MOSI=0; 
      }
      SPI_SCK=1;
      __delay_us(1);
      SPI_SCK=0;
      __delay_us(1); 
    }
}

unsigned char read_soft_SPI(void)
{
  unsigned char value=0;
  unsigned char i=0;
  
    SPI_SCK=0; 
    __delay_us(1);
    
    for(i=0;i<8;i++)
    {
      __delay_us(1);  
      if(RC4==1)
      {
         value=value|(0x80>>i);
      }
      SPI_SCK=1;
      __delay_us(1);
      SPI_SCK=0; 

    }
 return value;
}

void ft800memWrite8(unsigned long ftAddress, unsigned long ftData8)
{
  CS_Pin=0;
  __delay_us(2);
  
  write_soft_SPI((char)((ftAddress>>16)|MEM_WRITE));
  write_soft_SPI((char)(ftAddress >>8));
  write_soft_SPI((char)(ftAddress));
  write_soft_SPI((char)(ftData8));

  CS_Pin=1;
  
}

void ft800memWrite16(unsigned long ftAddress, unsigned long ftData16)
{
  CS_Pin=0;
  __delay_us(2);
  write_soft_SPI((char)((ftAddress>>16)|MEM_WRITE));
  write_soft_SPI((char)(ftAddress >>8));
  write_soft_SPI((char)(ftAddress));
  write_soft_SPI((char)(ftData16));
  write_soft_SPI((char)(ftData16 >> 8));
  CS_Pin=1;
}
void ft800memWrite32(unsigned long ftAddress, unsigned long ftData32)
{
  CS_Pin=0;
  __delay_us(2);
  write_soft_SPI((char)((ftAddress>>16)|MEM_WRITE));
  write_soft_SPI((char)(ftAddress >>8));
  write_soft_SPI((char)(ftAddress));
  write_soft_SPI((char)(ftData32));
  write_soft_SPI((char)(ftData32 >> 8));
  write_soft_SPI((char)(ftData32 >> 16));
  write_soft_SPI((char)(ftData32 >> 24));
  CS_Pin=1; 
  
}
unsigned char ft800memRead8(unsigned long ftAddress)
{
  unsigned char ftData8 = ZERO;
  CS_Pin = 0;		// Set CS# low
  __delay_us(2);
  
  write_soft_SPI((char)((ftAddress>>16)|MEM_READ));
  write_soft_SPI((char)(ftAddress >>8));
  write_soft_SPI((char)(ftAddress));
  write_soft_SPI(0);
  ftData8=read_soft_SPI();

  CS_Pin = 1;		// Set CS# high
    
  return ftData8;				// Return byte read
}

unsigned char ft800memRead16(unsigned long ftAddress)
{
   unsigned int ftData16, tempData[2];
   ftData16=0;
   
    CS_Pin = 0;		// Set CS# low
    __delay_us(2);

    write_soft_SPI((char)((ftAddress>>16)|MEM_READ));
    write_soft_SPI((char)(ftAddress >>8));
    write_soft_SPI((char)(ftAddress));
    write_soft_SPI(0);

    tempData[0]=read_soft_SPI();
    tempData[1]=read_soft_SPI();

    ftData16 = tempData[0] | (tempData[1] << 8);

    CS_Pin = 1;		// Set CS# high  
   
  return ftData16;				// Return byte read
}

unsigned long ft800memRead32(unsigned long ftAddress)
{
   unsigned long ftData32, tempData[4];
   ftData32=0;
   
    CS_Pin = 0;		// Set CS# low
    __delay_us(2);

    write_soft_SPI((char)((ftAddress>>16)|MEM_READ));
    write_soft_SPI((char)(ftAddress >>8));
    write_soft_SPI((char)(ftAddress));
    write_soft_SPI(0);

    tempData[0]=read_soft_SPI();
    tempData[1]=read_soft_SPI();
    tempData[2]=read_soft_SPI();
    tempData[3]=read_soft_SPI();

    ftData32 = tempData[0] | (tempData[1] << 8)|(tempData[2] << 16)|(tempData[3] << 24);

    CS_Pin = 1;		// Set CS# high  
   
    return ftData32;				// Return byte read
}

unsigned int incCMDOffset(unsigned int currentOffset, unsigned char commandSize)
{
    unsigned int newOffset;			// used to hold new offset
    newOffset = currentOffset + commandSize;	// Calculate new offset
    if(newOffset > 4095)			// If new offset past boundary...
    {
        newOffset = (newOffset - 4096);		// ... roll over pointer
    }
    return newOffset;				// Return new offset
}

void ft800cmdWrite(unsigned char ftCommand)
{
  CS_Pin=0;		// Set CS# low
  
  write_soft_SPI(ftCommand);
  write_soft_SPI(ZERO);
  write_soft_SPI(ZERO);
  
  CS_Pin=1;		// Set CS# high
}

unsigned char read_touch(void)
{
    unsigned char touch_tag;
    
	touch_tag=ft800memRead8(REG_TOUCH_TAG);

	switch(touch_tag)
	{
		case 1:
        page_number=2;
		break;
        case 2:
        if(update_toggle==1)
        {
            if(toggle_state==0)
            {
              toggle_state=0xFFFF0000;  
            }
            else
            {
              toggle_state=0;  
            }     
            update_toggle=0;
            __delay_ms(50);
        }
        break;
        case 0x31:
        ft800memWrite8(REG_GPIO, 0x82);
        ft800memWrite8(REG_VOL_SOUND,0xFF);									// volume 
        ft800memWrite16(REG_SOUND,0x4840);										// set synthesizer 
        ft800memWrite8(REG_PLAY,1);
        break;
        case 0x32:
        ft800memWrite8(REG_GPIO, 0x82);
        ft800memWrite8(REG_VOL_SOUND,0xFF);									// volume 
        ft800memWrite16(REG_SOUND,0x4846);										// set synthesizer 
        ft800memWrite8(REG_PLAY,1);
        break;
        case 0x33:
        ft800memWrite8(REG_GPIO, 0x82);
        ft800memWrite8(REG_VOL_SOUND,0xFF);									// volume 
        ft800memWrite16(REG_SOUND,0x4850);										// set synthesizer 
        ft800memWrite8(REG_PLAY,1);
        break;
        
        case 0x34:
        ft800memWrite8(REG_GPIO, 0x82);
        ft800memWrite8(REG_VOL_SOUND,0xFF);									// volume 
        ft800memWrite16(REG_SOUND,0x4849);										// set synthesizer 
        ft800memWrite8(REG_PLAY,1);
        break;
	}

	if(touch_tag>0||touch_tag<255)
	{
		 page_update=1;
	}
    
    if(touch_tag!=2)
    {
        update_toggle=1;
    }
   
    if(ft800memRead8(REG_PLAY)==0)
    {
       ft800memWrite8(REG_GPIO, 0x80);
    }
    
    return touch_tag;
}

void draw_rectangle(unsigned long color,unsigned long X_start,unsigned long Y_start,unsigned long X_stop,unsigned long Y_stop)
{
	X_start=X_start*16;
	Y_start=Y_start*16;

	X_stop=X_stop*16;
	Y_stop=Y_stop*16;

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_BEGIN |RECTS));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | color));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (long)(DL_VERTEX2F | (X_start << 15) | Y_start));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (long)(DL_VERTEX2F | (X_stop<< 15) | Y_stop));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_END));

    cmdOffset = incCMDOffset(cmdOffset, 4);
}


void draw_line(unsigned long color,unsigned long X_start,unsigned long Y_start,unsigned long X_stop,unsigned long Y_stop)
{
	X_start=X_start*16;
	Y_start=Y_start*16;

	X_stop=X_stop*16;
	Y_stop=Y_stop*16;

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_BEGIN |LINES));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | color));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_VERTEX2F | (X_start << 15) | Y_start));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_VERTEX2F |  (X_stop<< 15) | Y_stop));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_END));

    cmdOffset = incCMDOffset(cmdOffset, 4);
}

void draw_point(unsigned long color,unsigned long size, unsigned long X_start, unsigned long Y_start)
{
	X_start=X_start*16;
	Y_start=Y_start*16;

	size=size*16;

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_BEGIN |FTPOINTS));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | color));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_POINT_SIZE | size));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_VERTEX2F | (X_start << 15) | Y_start));

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_END));

    cmdOffset = incCMDOffset(cmdOffset, 4);
}

void draw_gauge()
{

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | RED));//needle_color

    cmdOffset = incCMDOffset(cmdOffset, 4);

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_BGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, WHITE);//Back_color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255) );//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, CMD_GAUGE);
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x003C0046); //y start, x start 
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00000032);//options, radius
												 // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x0005000A);//minor, major
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00640028);//range, value
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

}

void draw_clock()
{

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | RED));//needle_color

    cmdOffset = incCMDOffset(cmdOffset, 4);

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_BGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, WHITE);//back color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255) );//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, CMD_CLOCK);
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x003C00B4); //y start, x start 
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x003C0032);//options, radius
												 // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x0014000A);//minute, hour
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00000000);//mili second,second
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

}


void draw_dial()
{
    
    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | RED));//knob color

    cmdOffset = incCMDOffset(cmdOffset, 4);

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_FGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, WHITE);//back color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255));//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);
    
    ft800memWrite32(RAM_CMD + cmdOffset, CMD_DIAL);
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x003C0122);//y start, x start 
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x003C0032);//options, radius
												 // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x4000);//value
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

}


void draw_number()
{
    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | GREEN));//text color

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255));//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (CMD_NUMBER));
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00100154);//y start, x start 
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset, 0x0000001D);//options, font
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 1234567890);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

}


void draw_text()
{

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | BLACK));//textcolor

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255) );//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (CMD_TEXT));
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00300160);//y start, x start 
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset,  0x0000001D);//options, font
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    
    ft800memWrite32(RAM_CMD + cmdOffset,0x49445A4F);//OZDI

    cmdOffset = incCMDOffset(cmdOffset, 4);
    

    ft800memWrite32(RAM_CMD + cmdOffset,0x004E4153);//SAN, 0

    cmdOffset = incCMDOffset(cmdOffset, 4);
}

void draw_keys()
{
    unsigned char read_value=0;
    unsigned long options=0;
    
    read_value=ft800memRead8(REG_TOUCH_TAG);

    if(read_value==0x31)
    {
        options =0x0031001D;
    }
    else if(read_value==0x32)
    {
        options =0x0032001D;;
    }
    else if(read_value==0x33)
    {
        options =0x0033001D;;
    }
    else if(read_value==0x34)
    {
        options =0x0034001D;;
    }
    else
    {
       options =0x0000001D; 
    }

    
	ft800memWrite32(RAM_CMD + cmdOffset, CMD_FGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, WHITE);//foregroundcolor
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_BGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, GREEN);//presscolor
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset, CMD_GRADCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, BLACK);//gradcolor
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | BLUE));//textcolor

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255) );//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (CMD_KEYS));
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00800078);//y start, x start
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x004000C4);//height,witdh
												 // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, options);//options, font
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset,0x34333231);//1234

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset,0x00000000);// 0

    cmdOffset = incCMDOffset(cmdOffset, 4);

	ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(0));
	cmdOffset = incCMDOffset(cmdOffset, 4);

}



void draw_button()
{
    unsigned char read_value=0;
    
	ft800memWrite32(RAM_CMD + cmdOffset, CMD_FGCOLOR);

	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    read_value=ft800memRead8(REG_TOUCH_TAG);
    
	if(read_value==6)
	{
		ft800memWrite32(RAM_CMD + cmdOffset, WHITE);
		cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer
	}
	else
	{
		ft800memWrite32(RAM_CMD + cmdOffset, BLACK);	//	foregroundcolor						
		cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer
	}


	ft800memWrite32(RAM_CMD + cmdOffset, CMD_GRADCOLOR);

	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, WHITE);//gradcolor

	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB |BLUE ));//textcolor

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(1));
    cmdOffset = incCMDOffset(cmdOffset, 4);
    ft800memWrite32(RAM_CMD + cmdOffset, TAG(1));
    cmdOffset = incCMDOffset(cmdOffset, 4);
    
    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255) );

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (CMD_BUTTON));
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00DC0180);//y start, x start
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00300050);//height,witdh
												 // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x0000001D);//options, font
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	
    ft800memWrite32(RAM_CMD + cmdOffset,0x5458454E);//1234

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset,0x00000000);// 0

    cmdOffset = incCMDOffset(cmdOffset, 4);

	ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(0));
	cmdOffset = incCMDOffset(cmdOffset, 4);

}

void draw_slider()
{
	unsigned long read_value=0;

    ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(1));
    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, TAG(3));
    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, CMD_TRACK);
                                              // Instruct the graphics processor to show the list
    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, 0x00300020);//y start, x start
                                                  // End the point
    cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset, 0x002000C4);//height,witdh
                                                  // End the point
    cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset, 3);
                                                  // End the point
    cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    read_value=ft800memRead32(REG_TRACKER);

    if((read_value&0xFF)==3)
    {
        slider_value=(((read_value>>16)*100)/65536)+1;
    }

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | WHITE));//left_bar_color

    cmdOffset = incCMDOffset(cmdOffset, 4);

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_FGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, BLACK);//knob_color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255) );//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_BGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, GREEN);//right_bar_color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


    ft800memWrite32(RAM_CMD + cmdOffset, (CMD_SLIDER));
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00300020);//y start, x start
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x002000C4);//height,witdh
												 // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, (slider_value << 16));
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 100);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(0));
	cmdOffset = incCMDOffset(cmdOffset, 4);

}


void draw_progress()
{
	unsigned long read_value=0;

    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | WHITE));//inner_bar_color

    cmdOffset = incCMDOffset(cmdOffset, 4);

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_FGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, GREEN);//outer_bar_color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255) );//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, CMD_PROGRESS);
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00A00020);//y start, x start
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x002000C4);//height,witdh
												 // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00400000);//value ,options
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 100);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(0));
	cmdOffset = incCMDOffset(cmdOffset, 4);
}


void draw_scrollbar()
{
	unsigned long read_value=0;

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_FGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, WHITE);//inner_bar_color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_BGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, GREEN);//outer_bar_color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255) );//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, CMD_SCROLLBAR);
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00700020);//y start, x start
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x002000C4);//height,witdh
												 // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00200000);//value ,options
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x0064000A);//range ,size
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(0));
	cmdOffset = incCMDOffset(cmdOffset, 4);
}

void draw_toggle()
{
    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | BLUE));//textcolor

    cmdOffset = incCMDOffset(cmdOffset, 4);

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_BGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, WHITE);//bar_color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, CMD_FGCOLOR);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, RED);//knob_color
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

    ft800memWrite32(RAM_CMD + cmdOffset, COLOR_A(255) );//transparency

    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(1));
    cmdOffset = incCMDOffset(cmdOffset, 4);
    ft800memWrite32(RAM_CMD + cmdOffset, TAG(2));
    cmdOffset = incCMDOffset(cmdOffset, 4);

    ft800memWrite32(RAM_CMD + cmdOffset, (CMD_TOGGLE));
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00400140);//y start, x start
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x001D0060);//font, width
												 // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, toggle_state);//state, options
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

   
    ft800memWrite32(RAM_CMD + cmdOffset,0xFF46464F);
    
    cmdOffset = incCMDOffset(cmdOffset, 4);
    
    ft800memWrite32(RAM_CMD + cmdOffset,0x00004E4F);
    
    cmdOffset = incCMDOffset(cmdOffset, 4);

    

	ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(0));
	cmdOffset = incCMDOffset(cmdOffset, 4);

}


void draw_gradient()
{

    ft800memWrite32(RAM_CMD + cmdOffset, CMD_GRADIENT);
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00000000);//Y0,X0
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, WHITE);//RGB0
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x011001E0);//Y1,X1
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, RED);//RGB1
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

}

void draw_spinner()
{
    
    ft800memWrite32(RAM_CMD + cmdOffset, (DL_COLOR_RGB | BLACK));//textcolor

    cmdOffset = incCMDOffset(cmdOffset, 4);
    
    ft800memWrite32(RAM_CMD + cmdOffset, CMD_SPINNER);
	                                                  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00900170);//y start, x start
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, 0x00000000);
												  // End the point
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

}

void Page_1(void)
{
	do
	{
	  cmdBufferRd = ft800memRead16(REG_CMD_READ);        // Read the graphics processor read pointer
	  cmdBufferWr = ft800memRead16(REG_CMD_WRITE); // Read the graphics processor write pointer

	}while (cmdBufferWr != cmdBufferRd);                // Wait until the two registers match
    
    ft800memWrite16(REG_CMD_WRITE, 0);

	cmdOffset = 0;                        // The new starting point the first location after the last command

	ft800memWrite32(RAM_CMD + cmdOffset, (CMD_DLSTART));
												  // Start the display list
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset, (DL_CLEAR_RGB|BLUE));
												  // Set the default clear color to black
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset, (DL_CLEAR | CLR_COL | CLR_STN | CLR_TAG));
												  // Clear the screen - this and the previous prevent artifacts between lists
												  // Attributes are the color, stencil and tag buffers
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


    draw_gauge();
    
    draw_clock();
    
    draw_dial();
    
    draw_number();
    
    draw_text();
    
    draw_keys();
    
    draw_button();
    
    
   
    
    draw_point(RED,10,50,220);
    
    draw_rectangle(RED,20,120,80,180);
    
    draw_line(RED,20,250,80,260);
    
    

	ft800memWrite32(RAM_CMD + cmdOffset, (DL_DISPLAY));
											  // Instruct the graphics processor to show the list
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, (CMD_SWAP));
												  // Make this list active
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite16(REG_CMD_WRITE, (cmdOffset));
}

void Page_2(void)
{
	do
	{
	  cmdBufferRd = ft800memRead16(REG_CMD_READ);        // Read the graphics processor read pointer
	  cmdBufferWr = ft800memRead16(REG_CMD_WRITE); // Read the graphics processor write pointer

	}while (cmdBufferWr != cmdBufferRd);                // Wait until the two registers match
    
    ft800memWrite16(REG_CMD_WRITE, 0);

	cmdOffset = 0;                        // The new starting point the first location after the last command

	ft800memWrite32(RAM_CMD + cmdOffset, (CMD_DLSTART));
												  // Start the display list
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset, (DL_CLEAR_RGB|BLUE));
												  // Set the default clear color to black
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset, (DL_CLEAR | CLR_COL | CLR_STN | CLR_TAG));
												  // Clear the screen - this and the previous prevent artifacts between lists
												  // Attributes are the color, stencil and tag buffers
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer  
   
    draw_gradient();
    
    draw_slider();
    
    draw_scrollbar();
    
    draw_progress();
    
    draw_toggle();
    
    draw_spinner();
    
	ft800memWrite32(RAM_CMD + cmdOffset, (DL_DISPLAY));
											  // Instruct the graphics processor to show the list
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, (CMD_SWAP));
												  // Make this list active
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite16(REG_CMD_WRITE, (cmdOffset));
}

void init_FT800()
{
    unsigned char temp=0;
    unsigned char duty=0;

    // LCD display parameters
    lcdWidth   = 480;				// Active width of LCD display
    lcdHeight  = 272;				// Active height of LCD display
    lcdHcycle  = 548;				// Total number of clocks per line
    lcdHoffset = 43;				// Start of active line
    lcdHsync0  = 0;				// Start of horizontal sync pulse
    lcdHsync1  = 41;				// End of horizontal sync pulse
    lcdVcycle  = 292;				// Total number of lines per screen
    lcdVoffset = 12;				// Start of active screen
    lcdVsync0  = 0;				// Start of vertical sync pulse
    lcdVsync1  = 10;				// End of vertical sync pulse
    lcdPclk    = 5;				// Pixel Clock
    lcdSwizzle = 0;				// Define RGB output pins
    lcdPclkpol = 1;				// Define active edge of PCLK

    //wake up FT800

    PD_Pin=0; //
    __delay_ms(20);
    PD_Pin=1;
    __delay_ms(20);

    ft800cmdWrite(FT800_ACTIVE);			// Start FT800
    __delay_ms(5);					// Give some time to process
    ft800cmdWrite(FT800_CLKEXT);			// Set FT800 for external clock
    __delay_ms(5);					// Give some time to process
    ft800cmdWrite(FT800_CLK48M);			// Set FT800 for 48MHz PLL
    __delay_ms(5);
    ft800cmdWrite(FT800_CORERST);			// Set FT800 for 48MHz PLL
    __delay_ms(5);

    while ( temp != 0x7C)		// Read ID register - is it 0x7C?
    {
      temp=ft800memRead8(REG_ID);
      __delay_ms(10);
    } 

    ft800memWrite8(REG_PCLK, ZERO);		// Set PCLK to zero - don't clock the LCD until later
    ft800memWrite8(REG_PWM_DUTY, ZERO);		// Turn off backlight

  //***************************************
// Initialize Display
    ft800memWrite16(REG_HSIZE,   lcdWidth);	// active display width
    ft800memWrite16(REG_HCYCLE,  lcdHcycle);	// total number of clocks per line, incl front/back porch
    ft800memWrite16(REG_HOFFSET, lcdHoffset);	// start of active line
    ft800memWrite16(REG_HSYNC0,  lcdHsync0);	// start of horizontal sync pulse
    ft800memWrite16(REG_HSYNC1,  lcdHsync1);	// end of horizontal sync pulse
    ft800memWrite16(REG_VSIZE,   lcdHeight);	// active display height
    ft800memWrite16(REG_VCYCLE,  lcdVcycle);	// total number of lines per screen, incl pre/post
    ft800memWrite16(REG_VOFFSET, lcdVoffset);	// start of active screen
    ft800memWrite16(REG_VSYNC0,  lcdVsync0);	// start of vertical sync pulse
    ft800memWrite16(REG_VSYNC1,  lcdVsync1);	// end of vertical sync pulse
    ft800memWrite8(REG_SWIZZLE,  lcdSwizzle);	// FT800 output to LCD - pin order
    ft800memWrite8(REG_PCLK_POL, lcdPclkpol);	// LCD data is clocked in on this PCLK edge
						// Don't set PCLK yet - wait for just after the first display list
// End of Initialize Display
//***************************************


  //***************************************
// Configure Touch and Audio 
  
    ft800memWrite8(REG_TOUCH_MODE, TOUCHMODE_CONTINUOUS);			// touch
    ft800memWrite16(REG_TOUCH_RZTHRESH, 1200);						// Eliminate any false touches
    ft800memWrite16(REG_TOUCH_OVERSAMPLE, 10);
    ft800memWrite16(REG_TOUCH_SETTLE, 5);
    ft800memWrite16(REG_TOUCH_CHARGE, 6000);
    ft800memWrite16(REG_TOUCH_ADC_MODE, 1);

    ft800memWrite8(REG_VOL_PB, 0x00);											// turn recorded audio volume down
    ft800memWrite8(REG_VOL_SOUND,0x00);									// turn synthesizer volume down
    ft800memWrite16(REG_SOUND,(0x6000));										// set synthesizer to mute

// End of Configure Touch and Audio
//***************************************

    ft800memWrite16(REG_ROTATE, 0);
    
//***************************************
// Write Initial Display List & Enable Display

    ramDisplayList = RAM_DL;			// start of Display List
    ft800memWrite32(ramDisplayList, DL_CLEAR_RGB| BLACK); // Clear Color RGB   00000010 RRRRRRRR GGGGGGGG BBBBBBBB  (R/G/B = Colour values) default zero / black
    ramDisplayList += 4;				// point to next location
    ft800memWrite32(ramDisplayList, (DL_CLEAR | CLR_COL | CLR_STN | CLR_TAG));	// Clear 00100110 -------- -------- -----CST  (C/S/T define which parameters to clear)
    ramDisplayList += 4;				// point to next location
    ft800memWrite32(ramDisplayList, DL_DISPLAY);	// DISPLAY command 00000000 00000000 00000000 00000000 (end of display list)

    ft800memWrite32(REG_DLSWAP, DLSWAP_FRAME);	// 00000000 00000000 00000000 000000SS  (SS bits define when render occurs)
                          // Nothing is being displayed yet... the pixel clock is still 0x00
    ramDisplayList = RAM_DL;			// Reset Display List pointer for next list

    ft800memWrite8(REG_GPIO_DIR, 0x03);									// GPIO direciton
    
    ft800Gpio = ft800memRead8(REG_GPIO);		// Read the FT800 GPIO register for a read/modify/write operation
    ft800Gpio = ft800Gpio | 0x80;			// set bit 7 of FT800 GPIO register (DISP) - others are inputs
    ft800memWrite8(REG_GPIO, ft800Gpio);		// Enable the DISP signal to the LCD panel
    ft800memWrite8(REG_PCLK, lcdPclk);		// Now start clocking data to the LCD panel

    ft800memWrite8(REG_PWM_DUTY,128);

    do
	{
	  cmdBufferRd = ft800memRead16(REG_CMD_READ);        // Read the graphics processor read pointer
	  cmdBufferWr = ft800memRead16(REG_CMD_WRITE); // Read the graphics processor write pointer

	}while (cmdBufferWr != cmdBufferRd);                // Wait until the two registers match

	cmdOffset = cmdBufferWr;                        // The new starting point the first location after the last command

	ft800memWrite32(RAM_CMD + cmdOffset, (CMD_DLSTART));
												  // Start the display list
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset, (DL_CLEAR_RGB | BLUE));
												  // Set the default clear color to black
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset, (DL_CLEAR | CLR_COL | CLR_STN | CLR_TAG));
												  // Clear the screen - this and the previous prevent artifacts between lists
												  // Attributes are the color, stencil and tag buffers
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, TAG_MASK(0));
	cmdOffset = incCMDOffset(cmdOffset, 4);

	//ft800memWrite32(RAM_CMD + cmdOffset, CMD_CALIBRATE);
											  // Instruct the graphics processor to show the list
	//cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	//ft800memWrite32(RAM_CMD + cmdOffset, 0);
											  // Instruct the graphics processor to show the list
	//cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer


	ft800memWrite32(RAM_CMD + cmdOffset, (DL_DISPLAY));
												  // Instruct the graphics processor to show the list
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite32(RAM_CMD + cmdOffset, (CMD_SWAP));
												  // Make this list active
	cmdOffset = incCMDOffset(cmdOffset, 4);        // Update the command pointer

	ft800memWrite16(REG_CMD_WRITE, (cmdOffset));

	ft800memWrite32(REG_TOUCH_TRANSFORM_A, 0x00007DB5);
	ft800memWrite32(REG_TOUCH_TRANSFORM_B, 0xFFFFFEF6);
	ft800memWrite32(REG_TOUCH_TRANSFORM_C, 0xFFF61664);
	ft800memWrite32(REG_TOUCH_TRANSFORM_D, 0x00000048);
	ft800memWrite32(REG_TOUCH_TRANSFORM_E, 0xFFFFB387);
	ft800memWrite32(REG_TOUCH_TRANSFORM_F, 0x0119F874);
}
  

int main() 
{
    //www.ozdisan.com
    //sabri dageri
    //27.01.2017
    //https://www.ozdisan.com/tools-supplies-assistant-equipments/evaluation-and-demo-boards-kits/evaluation-boards/OZD-EVA-FT800-PIC-V1-1
    
    unsigned int i =0;
    
    TRISB=0b00000000; 
    TRISC=0b00010000;   
    TRISD=0b00000000; 
    TRISE=0b00000000; 
    ANSEL  = 0;                                    // Configure AN pins as digital I/O
    ANSELH = 0;
    
    SSPADD = 9;
    
    Led_1=0;
    Led_2=0;
    PD_Pin=1;
    CS_Pin=1;
    SPI_MOSI=0;
    SPI_MISO=0;
    SPI_SCK=0;
    
  
    init_FT800();
    
    page_update=1;
    page_number=1;
    


    while(1)
    {
        read_touch();
        if(page_update==1)
        {
            if(page_number==1)
            {
                Page_1();   
            }  
            if(page_number==2)
            {
                Page_2();   
            }
            page_update=0;
        }

    } 


}

